/********************************************************************************
* header.h: Inneh�ller diverse makrodefinitioner och funktionsdeklarationer
*           f�r implementering av det inbyggda systemet. Ett f�tal globala
*           datamedlemmar anv�nds f�r implementeringen. Eftersom dessa medlemmars
*           inneh�ll i detta fall kan �ndras mycket pl�tsligt via ett avbrott
*           s�tts dessa till flyktiga via nyckelordet volatile, vilket medf�r
*           att kompilatorn inte f�r genomf�ra n�gra optimeringar p� dessa,
*           utan lagrat v�rde m�ste l�sas in fr�n RAM-minnet varje g�ng det
*           anv�nds.
********************************************************************************/
#ifndef HEADER_H_
#define HEADER_H_

/* Klockfrekvens (definieras f�r implementering av f�rdr�jning): */
#define F_CPU 16000000UL /* Definierar klockfrekvensen till 16 MHz. */

/* Inkluderingsdirektiv: */
#include <avr/io.h>        /* Inneh�ller information om I/O-portar s�som DDRB och PORTB. */
#include <avr/interrupt.h> /* Inneh�ller information om avbrottsrutiner s�som INT0_vect. */
#include <util/delay.h>    /* Inneh�ller funktionalitet f�r f�rdr�jningsgenerering. */

/* Makrodefinitioner: */
#define LED1 0    /* Lysdiod 1 ansluten till pin 8 / PORTB0. */
#define LED2 1    /* Lysdiod 2 ansluten till pin 9 / PORTB1. */
#define LED3 2    /* Lysdiod 3 ansluten till pin 10 / PORTB2. */

#define BUTTON1 2 /* Tryckknapp 1 ansluten till pin 2 / PORTD2. */
#define BUTTON2 3 /* Tryckknapp 2 ansluten till pin 3 / PORTD3. */

#define LED1_ON PORTB |= (1 << LED1)   /* T�nder lysdiod 1. */
#define LED2_ON PORTB |= (1 << LED2)   /* T�nder lysdiod 2. */
#define LED3_ON PORTB |= (1 << LED3)   /* T�nder lysdiod 3. */

#define LED1_OFF PORTB &= ~(1 << LED1) /* Sl�cker lysdiod 1. */
#define LED2_OFF PORTB &= ~(1 << LED2) /* Sl�cker lysdiod 2. */
#define LED3_OFF PORTB &= ~(1 << LED3) /* Sl�cker lysdiod 3. */

#define LEDS_ON PORTB |= (1 << LED1) | (1 << LED2) | (1 << LED3)     /* T�nder lysdioderna. */
#define LEDS_OFF PORTB &= ~((1 << LED1) | (1 << LED2) | (1 << LED3)) /* Sl�cker lysdioder. */

#define BUTTON1_IS_PRESSED (PIND & (1 << BUTTON1)) /* Indikerar nedtryckning av tryckknapp 1. */
#define BUTTON2_IS_PRESSED (PIND & (1 << BUTTON2)) /* Indikerar nedtryckning av tryckknapp 2. */

/* Enumerationer: */
typedef enum { false = 0, true = 1 } bool; /* Realisear datatypen bool. */

/* Deklaration av globala datamedlemmar: */
extern volatile bool leds_enabled;       /* Indikerar lysdiodernas tillst�nd. */
extern volatile uint16_t blink_speed_ms; /* Lysdiodernas blinkhastighet. */

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt aktiverar externt avbrott INT0
*        p� stigande flank.
********************************************************************************/
void setup(void);

/********************************************************************************
* led_toggle: Togglar lysdiodernas tillst�nd. Om lysdioderna inaktiveras s�
*             sl�cks samtliga lysdioder direkt, annars g�rs ingenting.
********************************************************************************/
void led_toggle(void);

/********************************************************************************
* led_blink: Blinkar lysdioderna med angiven blinkhastighet, som passeras via 
*            pekare f�r att direkt kunna justeras under en given blinkning.
*            Annars om en kopia skickas s� �r detta inte m�jligt, men vid 
*            anv�ndning av pekare fungerar det enkelt att �ndra blinkhastigheten
*            p� angiven minnesadress.
*
*            Kontroll sker att lysdioderna fortfarande �r aktiverade inf�r
*            varje blinkning s� att blinkningen avbryts direkt vid inaktivering.
*
*            - blink_speed_ms: Pekare till angiven blinkhastighet.
********************************************************************************/
void led_blink(const volatile uint16_t* blink_speed_ms);

#endif /* HEADER_H_ */