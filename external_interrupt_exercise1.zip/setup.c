/********************************************************************************
* setup.c: Inneh�ller initieringsrutiner f�r det inbyggda systemet.
********************************************************************************/
#include "header.h"

/* Definition av globala datamedlemmar: */
volatile bool leds_enabled = false;     /* Lysdioderna sl�ckta vid start. */
volatile uint16_t blink_speed_ms = 500; /* 500 ms blinkhastighet vid start. */

/* Statiska funktioner: */
static inline void init_ports(void);
static inline void init_interrupts(void);

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt aktiverar externa avbrott 
*        INT0 - INT1 p� stigande flank.
********************************************************************************/
void setup(void)
{
   init_ports();
   init_interrupts();
   return;
}

/********************************************************************************
* init_ports: Initierar mikrodatorns I/O-portar. F�rst s�tts lysdiodernas pinnar
*             till utportar via ettst�llning av motsvarandear bitar i
*             datariktningsregister DDRB. 
*
*             D�refter aktiveras de interna pullup-resistorna p� tryckknapparnas 
*             pinnar f�r att insignalerna alltid ska bli h�ga (1) eller l�ga (0). 
*             Som default �r insignalerna annars flytande mellan 0 - 1, ett 
*             tillst�nd som inom digitaltekniken kallas tri-state.
********************************************************************************/
static inline void init_ports(void)
{
   DDRB = (1 << LED1) | (1 << LED2) | (1 << LED3);
   PORTD = (1 << BUTTON1) | (1 << BUTTON2);
   return;
}

/********************************************************************************
* init_interrupts: Aktiverar externa avbrott INT0 - INT1 p� stigande flank. 
*
*                  F�rst aktiveras avbrott globalt via ettst�llning av I-flaggan 
*                  i CPU:ns statusregister SREG. F�r att ettst�lla I-flaggan
*                  anv�nds assemblerinstruktionen SEI.
*
*                  D�refter aktiveras eventdetektering p� stigande flank f�r
*                  avbrott INT0 - INT1 via ettst�llning av ISC-bit ISC00 - ISC11
*                  i kontrollregister EICRA. 
*
*                  Slutligen aktiveras avbrott INT0 - INT1 via ettst�llning av  
*                  bitarna med samma namn i maskregister EIMSK.
*
*                  Notering:
*                  - SEI   = Set Interrupt Flag.
*                  - EICRA = External Interrupt Control Register A.
*                  - EIMSK = External Interrupt Mask Register.
*                  - ISC   = Interrupt Sense Control.
********************************************************************************/
static inline void init_interrupts(void)
{
   asm("SEI");
   EICRA = (1 << ISC00) | (1 << ISC01) | (1 << ISC10) | (1 << ISC11);
   EIMSK = (1 << INT0) | (1 << INT1);
   return;
}