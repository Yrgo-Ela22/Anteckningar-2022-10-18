/********************************************************************************
* main.c: Interruptbaserad styrning av tre lysdioder anslutna till pin 8 - 10
*         via nedtryckning av tryckknappar anslutna till pin 2 - 3. 
*
*         Externa avbrott INT0 - INT1 �r aktiverade f�r eventdetektering p�
*         stigande flank (nedtryckning av tryckknapparna), vilket anv�nds f�r
*         att toggla lysdioderna mellan att blinka med en viss blinkhastighet
*         samt vara avst�ngda. 
*
*         Vid nedtryckning av tryckknappen ansluten till pin 2 s�tts 
*         blinkhastigheten till 500 ms, annars vid nedtryckning av tryckknappen 
*         ansluten till pin 3 s�tts blinkhastigheten till 100 ms.
*         Vid inaktivering av lysdioderna s�tts blinkhastigheten tempor�rt till 
*         noll f�r att direkt avbryta eventuell blinkning.
********************************************************************************/
#include "header.h"

/********************************************************************************
* main: Initierar mikrodatorn vid start. Ifall lysdioderna �r aktiverade s�
*       blinkar dessa med en viss f�rdr�jningstid, som avg�rs av vilken av
*       tryckknapparna som senast trycktes ned. Annars h�lls lysdioderna sl�ckta.
********************************************************************************/
int main(void)
{
   setup();

   while (1) 
   {
      if (leds_enabled)
      {
         led_blink(&blink_speed_ms);
      }
   }

   return 0;
}

