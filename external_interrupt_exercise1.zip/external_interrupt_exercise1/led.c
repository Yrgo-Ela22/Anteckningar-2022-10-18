/********************************************************************************
* led.c: Inneh�ller diverse funktioner f�r styrning av lysdioder.
********************************************************************************/
#include "header.h"

/* Statiska funktioner: */
static void delay_ms(const volatile uint16_t* delay_time_ms);

/********************************************************************************
* led_toggle: Togglar lysdiodernas tillst�nd. Om lysdioderna inaktiveras s�
*             sl�cks samtliga lysdioder direkt och blinkhastigheten s�tts
*             direkt till 0 f�r att avbryta eventuell blinkning.
********************************************************************************/
void led_toggle(void)
{
   leds_enabled = !leds_enabled;

   if (!leds_enabled)
   {
      LEDS_OFF;
      blink_speed_ms = 0;
   }

   return;
}

/********************************************************************************
* led_blink: Blinkar lysdioderna med angiven blinkhastighet, som passeras via
*            pekare f�r att direkt kunna justeras under en given blinkning.
*            Annars om en kopia skickas s� �r detta inte m�jligt, men vid
*            anv�ndning av pekare fungerar det enkelt att �ndra blinkhastigheten
*            p� angiven minnesadress.
*
*            Kontroll sker att lysdioderna fortfarande �r aktiverade inf�r
*            varje blinkning s� att blinkningen avbryts direkt vid inaktivering.
*
*            - blink_speed_ms: Pekare till angiven blinkhastighet.
********************************************************************************/
void led_blink(const volatile uint16_t* blink_speed_ms)
{
   if (!leds_enabled) return;
   LED1_ON;
   LED2_OFF;
   LED3_OFF;
   delay_ms(blink_speed_ms);

   if (!leds_enabled) return;
   LED1_OFF;
   LED2_ON;
   delay_ms(blink_speed_ms);

   if (!leds_enabled) return;
   LED2_OFF;
   LED3_ON;
   delay_ms(blink_speed_ms);

   return;
}

/********************************************************************************
* delay_ms: Genererar specificerad f�rdr�jning m�tt i millisekunder. 
*           F�rdr�jningstiden passeras via pekare f�r att direkt kunna justeras 
*           under en f�rdr�jning.
*
*           - delay_time_ms: Pekare till f�rdr�jningstiden m�tt i millisekunder.
********************************************************************************/
static void delay_ms(const volatile uint16_t* delay_time_ms)
{
   for (uint16_t i = 0; i < *delay_time_ms; ++i)
   {
      _delay_ms(1);
   }

   return;
}