/********************************************************************************
* interrupts.c: Inneh�ller diverse avbrottsrutiner.
********************************************************************************/
#include "header.h"

/********************************************************************************
* ISR (INT0_vect): Avbrottsrutin som �ger rum vid event p� stigande flank p�
*                  pin 2 / PORTD2, i praktiken nedtryckning av tryckknapp 2.
*                  Lysdiodernas tillst�nd togglas och aktuell blinkhastighet 
*                  s�tts till 500 ms.
********************************************************************************/
ISR (INT0_vect)
{
   led_toggle();
   blink_speed_ms = 500;
   return;
}

/********************************************************************************
* ISR (INT1_vect): Avbrottsrutin som �ger rum vid event p� stigande flank p�
*                  pin 3 / PORTD3, i praktiken nedtryckning av tryckknapp 2. 
*                  Lysdiodernas tillst�nd togglas och aktuell blinkhastighet 
*                  s�tts till 100 ms.
********************************************************************************/
ISR (INT1_vect)
{
   led_toggle();
   blink_speed_ms = 100;
   return;
}